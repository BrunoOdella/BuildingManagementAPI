﻿namespace Models.In;

public class MaintenancePersonRequest
{
    public Guid Id { get; set; }
}