﻿namespace Domain;

public class Report
{
    public List<BuildingReport> BuildingReports { get; set; }
    public List<MaintenanceStaffReport> MaintenanceStaffReports { get; set; }
}