﻿namespace Domain
{
    public enum Status
    {
        Active,
        Finished,
        Pending
    }
}