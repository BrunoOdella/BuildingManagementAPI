﻿namespace Domain
{
    public class AuthenticationResult
    {
        public Guid UserID { get; set; }
        public string UserType { get; set; }
    }
}
