﻿namespace Models.In;

public class ImportBuildingRequest
{
    public string AssemblyPath { get; set; }
}