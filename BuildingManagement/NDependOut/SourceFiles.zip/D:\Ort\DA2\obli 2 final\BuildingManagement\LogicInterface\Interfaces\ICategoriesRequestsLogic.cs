﻿using Domain;

namespace LogicInterface.Interfaces;

public interface ICategoriesRequestsLogic
{
    Category CreateCategory(Category category);
    IEnumerable<Category> GetAllCategories();
}