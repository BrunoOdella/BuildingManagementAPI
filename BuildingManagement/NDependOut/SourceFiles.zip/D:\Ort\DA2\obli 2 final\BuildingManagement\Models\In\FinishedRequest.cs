﻿namespace Models.In;

public class FinishedRequest
{
    public float TotalCost { get; set; }
    public DateTime EndTime { get; set; }
}