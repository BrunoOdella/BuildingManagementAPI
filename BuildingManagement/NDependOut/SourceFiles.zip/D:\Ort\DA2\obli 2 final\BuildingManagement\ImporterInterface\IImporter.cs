﻿namespace ImporterInterface;

public interface IBuildingImporter
{
    List<BuildingDTO> ImportBuilding();
}