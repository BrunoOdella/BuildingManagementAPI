﻿
using Domain;

namespace LogicInterface.Interfaces
{
    public interface IAdminLogic
    {
        Admin CreateAdmin(Admin admin);
    }
}
